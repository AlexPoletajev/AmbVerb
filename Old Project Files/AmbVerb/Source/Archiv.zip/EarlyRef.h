//
//  EarlyRef.h
//  AmbVerb
//
//  Created by anonym on 15.04.17.
//
//

#ifndef __AmbVerb__EarlyRef__
#define __AmbVerb__EarlyRef__

#include <iostream>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>    /* srand, rand */
#include <string.h>
#include "time.h"
#include "math.h"
#include <Accelerate/Accelerate.h>
//==============================================================================

#define earlyref_Log2N 15
#define	earlyref_Buffersize	(1u<<earlyref_Log2N)	// Number of elements.
#define Qx 1.9f
#define Qy 1.3f
#define maxNumChannels 64
#define Ambisonics_Order_MAX 7
#define AmbisonicsOrder 5
#define Trunc	8
#define numChannels 36 

//==============================================================================
class EarlyRef
{
public:
    
    int OnsetLength;
    EarlyRef(int Start);
    EarlyRef();
    ~EarlyRef();
    void processBlock(const float* Block[numChannels], int DspBlocksize, int NumOutputChannels, double pB_Samplerate); // DSP-Cycle
    void set_Q(float f);
    void set_RotAngle(float f);
    void set_EarlyrefVolume(float Value);
    int getQ(){return Q;};
    void readTransformationMatrix(std::string Path);//Einlesen der Rzx, Rxz, Rzy, Ryz Transformationsmatrizen

    //==============================================================================
    
    
    
    //==============================================================================
    
    float * OutBuffer[maxNumChannels]; //Buffer für das Ergebnis der Rotationen
    float * Output[maxNumChannels]; //Endgültiger Ausgabebuffer der Erstreflexionen
    int EarlyrefDelayTime, EndOfIR, IRsymmetryPoint; //Verzögerung, Anfangssample der Ersreflexionen, Ende der Erstreflexionen
    float FilterCoeffA, FilterCoeffB; // Filterkoeffizienten des Tiefpass'
    
    
    //==============================================================================
private:
    float h(float alpha, float beta, int lambda); // hankelfunktion
    void fillhBuffer(float phi, int offset, int Q); // Berechnung der dünnbesetzten Impulsantworten für Rz
    void CalculateRotationMatrices(int QValue, float PhiValue); //Start der Matrizenberechnungen
    void UnlockRotationMatrixForCalculaion(); //Freigabe der neuberechneten Matrizen für den Signalfluss (Vermeidung von Glitches)
    void CalculateRx();
    void CalculateRy();
    void CalculateRz(int QValue, float PhiValue);
    void CalculateRxyz();
    void CheckforNonZeroEntriesX();
    void CheckforNonZeroEntriesY();
    void CheckforNonZeroEntriesZ();
    void CheckforNonZeroEntriesXYZ();
    void GetImpulsResponse(); //IR Messen
    void Analyse(); //Analyse, wird nur in der Entwicklungsphase Gebraucht
    void MatrixConvolution(bool Flag_3D2D); //Mehrdimensional Faltung der Endgültigen Rotationsmatrix mit dem Eingangsvektor
    void FFTconvolution(float* IR1, DSPSplitComplex * IR2, float * FFTConvolutionBuffer); //Eindimensionale Faltung
    void On(); // Synthese An
    void Off(); //Synthese Aus
    void CalculateDelay(float PhiValue); //Berechnung der nötigen Verzögerungszeit der Erstreflexionen
    float LowPass ( float *LP_Input, double LP_a, double LP_p, float LP_initialSample, float * LP_FilterBuffer, const int LP_Blocksize);
    
    
    //int numChannels;
    int Ambisonics_Order;
    int BlockSize;
    bool OnOff; //Synthese An/Aus
    float earlyrefVolume;
    int Q, Q_TEMP, Phi;
	
    float * InBuffer[maxNumChannels]; //Eingangssignal Vektor
    
    float * DummyMatrix1[maxNumChannels][maxNumChannels]; // Temporäre SignalMatrix für Berechnungen
    float * Rx[maxNumChannels][maxNumChannels], * Ry[maxNumChannels][maxNumChannels], * Rz10[maxNumChannels][maxNumChannels], * Rz13[maxNumChannels][maxNumChannels], * Rz19[maxNumChannels][maxNumChannels]; // Rotations-FaltungsMatrizen mit Impulsantworten im Zeitbereich
    float   Rxz[maxNumChannels][maxNumChannels],Rzx[maxNumChannels][maxNumChannels],Ryz[maxNumChannels][maxNumChannels],Rzy[maxNumChannels][maxNumChannels]; // Transformationsmatrizen zur Abbildung der x,y-Achse auf die z-Achse und zurück
    float * Rxyz[maxNumChannels][maxNumChannels];
    float * hBuffer[(Ambisonics_Order_MAX*2+1)*2];   // dünnbesetzten Impulsantworten für Rz:  h(m,phi)
    float * dummyBuffer1[maxNumChannels]; //Hilfsbuffer für Berechnungen
    float * IR[maxNumChannels], *IR_TEMP[maxNumChannels]; //Buffer für Impulsantworten des Systems
    float * DUMMYVECTOR1, * DUMMYVECTOR2; //Hilfsvektor für Berechnungen
    float Filter_InitialSample[maxNumChannels]; //Initiales Sample für Tiefpass(Kausalität)
    float * FilterBuffer; //Buffer für Filterausgabe
    
    int check;
    
    
    int NonZeroEntriesX[maxNumChannels][maxNumChannels],NonZeroEntriesY[maxNumChannels][maxNumChannels],NonZeroEntriesZ[maxNumChannels][maxNumChannels],NonZeroEntriesXYZ[maxNumChannels][maxNumChannels],NonZeroEntriesXYZ_TEMP[maxNumChannels][maxNumChannels]; //Andere Matrixeinträge können bei Berechnungen übersprungen werden
    
    // Variablen für fft
    DSPSplitComplex  fft_Rxyz[maxNumChannels][maxNumChannels],fft_Rxyz_TEMP[maxNumChannels][maxNumChannels], fft_Rx[maxNumChannels][maxNumChannels], fft_Ry[maxNumChannels][maxNumChannels], fft_Rz[maxNumChannels][maxNumChannels]; //Rotationsmatrizen im Spektralbereich
    DSPSplitComplex SplitComplexBuffer1, SplitComplexBuffer2 ; //HilfsMatrizen für Berechnungen im Spektralbereich
    float * FFTconvBuffer1, *FFTconvBuffer2; //Hilfs-buffer für Berechnungen im Spektralbereich
    FFTSetup fftConvSetup;
    float fftScale; //Skalierung der fft Ergebnisse
    
    //==============================================================================
};


#endif /* defined(__AmbVerb__EarlyRef__) */
