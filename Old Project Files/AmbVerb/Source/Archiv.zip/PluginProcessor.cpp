/*
 ==============================================================================
 
 This file was auto-generated!
 
 It contains the basic framework code for a JUCE plugin processor.
 
 ==============================================================================
 */

#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "time.h"

//==============================================================================
AmbverbAudioProcessor::AmbverbAudioProcessor(int Start)
#ifndef JucePlugin_PreferredChannelConfigurations
: AudioProcessor (BusesProperties()
#if ! JucePlugin_IsMidiEffect
#if ! JucePlugin_IsSynth
                  .withInput  ("Input",  AudioChannelSet:: discreteChannel0(36), true)
#endif
                  .withOutput ("Output", AudioChannelSet:: discreteChannel0(36), true)
#endif
                  )
#endif
{
    
    
}
//==============================================================================
AmbverbAudioProcessor::AmbverbAudioProcessor()
#ifndef JucePlugin_PreferredChannelConfigurations
: AudioProcessor (BusesProperties()
#if ! JucePlugin_IsMidiEffect
#if ! JucePlugin_IsSynth
                  .withInput  ("Input",  AudioChannelSet:: discreteChannel0(36), true)
#endif
                  .withOutput ("Output", AudioChannelSet:: discreteChannel0(36), true)
#endif
                  )
#endif
{
    
    printf("Audioprozessor Constructor\n");
    
    
    for (int i = 0; i < ((AmbisonicsOrder+1)*(AmbisonicsOrder+1)); i++) {
        DirectSoundBuffer[i] =  (float*) calloc(earlyref_Buffersize, sizeof(DirectSoundBuffer[i]));
        
        if (DirectSoundBuffer[i] == nullptr) {
            perror("Error Allocating Memory");return;
        }
        EarlyrefBuffer[i] =  (float*) calloc(earlyref_Buffersize, sizeof(EarlyrefBuffer[i]));
        
        if (EarlyrefBuffer[i] == nullptr) {
            perror("Error Allocating Memory");return;
        }
    }
    
    
    // - - - - - Initialize Audio Parameter - - - - -
    
    addParameter (FdnVolume = new AudioParameterFloat ("FdnVolume", "Late Reverb", 0.0f, 1.0f, 0.7f));
    addParameter (EarlyrefVolume = new AudioParameterFloat ("EarlyrefVolume", "Early Reflections", 0.0f, 1.0f, 0.7f));
    addParameter (ReverbVolume = new AudioParameterFloat ("ReverbVolume", "LR/ER Volume", 0.0f, 1.0f, 1.0f));
    addParameter (Distance = new AudioParameterFloat ("Distance", "Distance", 0.0f, 1.0f, 0.0f));
    addParameter (FdnT60 = new AudioParameterFloat ("FdnT60", "T60(0Hz)", 0.0f, 10.0f, 2.0f));
    addParameter (FdnT60Ratio = new AudioParameterFloat ("FdnT60Ratio", "T60(0Hz)/T60(24 kHz)", 0.0f, 1.0f, 0.25f));
    
    addParameter (Roomsize = new AudioParameterFloat ("Roomsize", "Roomsize", fdnDelayMin, fdnDelayMax, fdnDelayMin));
    this->earlyref.set_Q(Qmin+(*Roomsize-fdnDelayMin)/(fdnDelayMax-fdnDelayMin)*(Qmax-Qmin));
    
    // - - - - - Activiere IR Subtraction innerhalb der FDN  - - - - -
    this->fdn.IRSubtracionOn(WindowStartMultiplikator*(int)(*Roomsize), WindowStartMultiplikator*(int)(*Roomsize)+this->earlyref.OnsetLength*
                             WindowEndMultiplikator);
    

    
    
    
    
    
    File RotationMatrixDirectory = (File::getSpecialLocation(currentExecutableFile).getParentDirectory().getFullPathName()+"/RotationMatrices");
    
    std::cout<<"PATH1:  "<< (File::getSpecialLocation(currentExecutableFile).getParentDirectory().getFullPathName()+"/RotationMatrices")<<"\n";
    
    if (RotationMatrixDirectory.exists()==0) {
        
        FileChooser myChooser ("Please select Location of RotationMatrices...",
                               File::getSpecialLocation (File::userHomeDirectory),
                               "");
        if (myChooser.browseForDirectory())
        {
            File filePath =  myChooser.getResult().getFullPathName();
            filePath.copyDirectoryTo(File::getSpecialLocation(currentExecutableFile).getParentDirectory().getFullPathName()+"/RotationMatrices");
            std::cout<<"PATH2:  "<< myChooser.getResult().getFullPathName()<<"\n";
            
        }
        else std::cout<<"PRoblem\n";
        
    }
    
    this->earlyref.readTransformationMatrix((RotationMatrixDirectory.getFullPathName()).toStdString());
    
    
}

AmbverbAudioProcessor::~AmbverbAudioProcessor()
{
}

//==============================================================================


const String AmbverbAudioProcessor::getName() const
{
    return JucePlugin_Name;
}

bool AmbverbAudioProcessor::acceptsMidi() const
{
#if JucePlugin_WantsMidiInput
    return true;
#else
    return false;
#endif
}

bool AmbverbAudioProcessor::producesMidi() const
{
#if JucePlugin_ProducesMidiOutput
    return true;
#else
    return false;
#endif
}

double AmbverbAudioProcessor::getTailLengthSeconds() const
{
    return 0.0;
}

int AmbverbAudioProcessor::getNumPrograms()
{
    return 1;   // NB: some hosts don't cope very well if you tell them there are 0 programs,
    // so this should be at least 1, even if you're not really implementing programs.
}

int AmbverbAudioProcessor::getCurrentProgram()
{
    return 0;
}

void AmbverbAudioProcessor::setCurrentProgram (int index)
{
}

const String AmbverbAudioProcessor::getProgramName (int index)
{
    return String();
}

void AmbverbAudioProcessor::changeProgramName (int index, const String& newName)
{
}

//==============================================================================
void AmbverbAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    // Use this method as the place to do any pre-playback
    // initialisation that you need..
}

void AmbverbAudioProcessor::releaseResources()
{
    // When playback stops, you can use this as an opportunity to free up any
    // spare memory, etc.
}

#ifndef JucePlugin_PreferredChannelConfigurations
bool AmbverbAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
#if JucePlugin_IsMidiEffect
    ignoreUnused (layouts);
    return true;
#else
    // This is the place where you check if the layout is supported.
    // In this template code we only support mono or stereo.
    if (layouts.getMainOutputChannelSet() != discreteChannel0(36)
        && layouts.getMainOutputChannelSet() != discreteChannel0(36)){}
    return false;
    
    // This checks if the input layout matches the output layout
#if ! JucePlugin_IsSynth
    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet()){}
    return false;
#endif
    
    return true;
#endif
}
#endif

void AmbverbAudioProcessor::processBlock (AudioSampleBuffer& buffer, MidiBuffer& midiMessages)
{
    
    float time1= clock();
    
    const int totalNumInputChannels  = getTotalNumInputChannels();
    const int totalNumOutputChannels = getTotalNumOutputChannels();
    
    // In case we have more outputs than inputs, this code clears any output
    // channels that didn't contain input data, (because these aren't
    // guaranteed to be empty - they may contain garbage).
    // This is here to avoid people getting screaming feedback
    // when they first compile a plugin, but obviously you don't need to keep
    // this code if your algorithm always overwrites all the output channels.
    for (int i = totalNumInputChannels; i < totalNumOutputChannels; ++i)
        buffer.clear (i, 0, buffer.getNumSamples());
    
    
    const float ** inBuffer = buffer.getArrayOfReadPointers();
    float ** outBuffer = buffer.getArrayOfWritePointers();
    int Blocksize = buffer.getNumSamples();
    int DS_ER_Delay = (int)(WindowStartMultiplikator* *Roomsize);
    
    earlyref.processBlock(inBuffer, buffer.getNumSamples(), totalNumOutputChannels, getSampleRate()); //erzeuge Erstreflexionen
    for (int i = 0; i < totalNumOutputChannels; ++i) {
        memmove(EarlyrefBuffer[i], EarlyrefBuffer[i]+Blocksize, (earlyref_Buffersize - Blocksize)*sizeof(float));
        memcpy(EarlyrefBuffer[i]+earlyref_Buffersize-Blocksize, earlyref.Output[i], Blocksize*sizeof(float));
        memmove(DirectSoundBuffer[i], DirectSoundBuffer[i]+Blocksize, (earlyref_Buffersize - Blocksize)*sizeof(float));
        memcpy(DirectSoundBuffer[i]+earlyref_Buffersize-Blocksize, inBuffer[i], Blocksize*sizeof(float));
    }
    
    fdn.processBlock(inBuffer[0], buffer.getNumSamples(), totalNumOutputChannels, getSampleRate()); //erzeuge Nachhall
    
    
    for (int i = 0; i < totalNumOutputChannels; ++i) {
        
        vDSP_vsmul(DirectSoundBuffer[i]+earlyref_Buffersize-Blocksize-DS_ER_Delay+100, 1, &DirectSoundVolume, outBuffer[i], 1, buffer.getNumSamples()); //Ausgabe des Direktschalls
        //vDSP_vsmul(outBuffer[i], 1, &DirectSoundVolume, outBuffer[i], 1, buffer.getNumSamples()); //Ausgabe des Direktschalls
        
        vDSP_vsma(EarlyrefBuffer[i]+earlyref_Buffersize-Blocksize-DS_ER_Delay, 1, &ReverbVol, outBuffer[i], 1, outBuffer[i], 1, buffer.getNumSamples());//Ausgabe der Erstreflexionen
        //vDSP_vsma(earlyref.Output[i], 1, &ReverbVol, outBuffer[i], 1, outBuffer[i], 1, buffer.getNumSamples());//Ausgabe der Erstreflexionen
        vDSP_vsma(fdn.Output[i], 1, &ReverbVol, outBuffer[i], 1, outBuffer[i], 1, buffer.getNumSamples());//Ausgabe des Nachhalls
    }
    
    /*
     if (fdn.check%200 == 0) {
     float      time2= clock();
     printf("'AmbVerb_DSP():    Time: = %f\n", (time2-time1)/CLOCKS_PER_SEC*44100);
     printf("NumOutputs : = %i\n",totalNumOutputChannels);
     printf("NumInputs : = %i\n",totalNumInputChannels);
     
     
     }
     fdn.check++;
     */
}

//==============================================================================
bool AmbverbAudioProcessor::hasEditor() const
{
    return true; // (change this to false if you choose to not supply an editor)
}

AudioProcessorEditor* AmbverbAudioProcessor::createEditor()
{
    return new AmbverbAudioProcessorEditor (*this);
}

//==============================================================================
void AmbverbAudioProcessor::getStateInformation (MemoryBlock& destData)
{
    // You should use this method to store your parameters in the memory block.
    
    
    ScopedPointer<XmlElement> xml (new XmlElement ("ParamAmbverb"));
    xml->setAttribute ("FdnVolume", (double) *FdnVolume);
    copyXmlToBinary (*xml, destData);
    xml->setAttribute ("EarlyrefVolume", (double) *EarlyrefVolume);
    copyXmlToBinary (*xml, destData);
    xml->setAttribute ("ReverbVolume", (double) *ReverbVolume);
    copyXmlToBinary (*xml, destData);
    xml->setAttribute ("Distance", (double) *Distance);
    copyXmlToBinary (*xml, destData);
    xml->setAttribute ("FdnT60", (double) *FdnT60);
    copyXmlToBinary (*xml, destData);
    xml->setAttribute ("FdnT60Ratio", (double) *FdnT60Ratio);
    copyXmlToBinary (*xml, destData);
    xml->setAttribute ("Roomsize", (double) *Roomsize);
    copyXmlToBinary (*xml, destData);
    
    
    
}

void AmbverbAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    // You should use this method to restore your parameters from this memory block,
    
    ScopedPointer<XmlElement> xmlState (getXmlFromBinary (data, sizeInBytes));
    if (xmlState != nullptr){
        
        printf("setStateinformation\n");
        if (xmlState->hasTagName ("ParamAmbverb")){
            
            *FdnVolume = xmlState->getDoubleAttribute ("FdnVolume", 0.7);
            this->fdn.set_Volume(*FdnVolume);
            
            *EarlyrefVolume = xmlState->getDoubleAttribute ("EarlyrefVolume", 0.7);
            this->earlyref.set_EarlyrefVolume(*EarlyrefVolume);
            
            *ReverbVolume = xmlState->getDoubleAttribute ("ReverbVolume", 1.0);
            if (*ReverbVolume == 0){ReverbVol = 0;}
            else {ReverbVol =  0.01*exp(4.605170*(*ReverbVolume));}
            
            *Distance = xmlState->getDoubleAttribute ("Distance", 0.0);
            if (*Distance == 1){DirectSoundVolume = 0;}
            else {DirectSoundVolume =  0.01*exp(4.605170*(1.0-*Distance));}
            
            
            *FdnT60 = xmlState->getDoubleAttribute ("FdnT60", 2.0);
            this->fdn.set_T60(*FdnT60);
            this->earlyref.FilterCoeffA = this->fdn.a0[0];
            this->earlyref.FilterCoeffB = this->fdn.p[0];
            
            *FdnT60Ratio = xmlState->getDoubleAttribute ("FdnT60Ratio", 0.25);
            this->fdn.set_T60Ratio(*FdnT60Ratio);
            this->earlyref.FilterCoeffA = this->fdn.a0[0];
            this->earlyref.FilterCoeffB = this->fdn.p[0];
            
            float Helper= *Roomsize;
            *Roomsize = xmlState->getDoubleAttribute ("Roomsize", fdnDelayMin);
            if (Helper != *Roomsize) {
                this->earlyref.set_Q(Qmin+(*Roomsize-fdnDelayMin)/(fdnDelayMax-fdnDelayMin)*(Qmax-Qmin));
                this->fdn.IRSubtracionOn(WindowStartMultiplikator*(int)(*Roomsize),WindowStartMultiplikator*(int)(*Roomsize)+ earlyref.OnsetLength*
                                         WindowEndMultiplikator);
                
            }
            
            
            
        }
        
    }
    
}

//==============================================================================
// This creates new instances of the plugin..
AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new AmbverbAudioProcessor();
}
